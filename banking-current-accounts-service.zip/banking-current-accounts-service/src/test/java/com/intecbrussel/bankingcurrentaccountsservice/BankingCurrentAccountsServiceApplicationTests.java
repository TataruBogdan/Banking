package com.intecbrussel.bankingcurrentaccountsservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingCurrentAccountsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
