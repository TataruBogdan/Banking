package com.intecbrussel.bankingcurrentaccountsservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankingCurrentAccountsServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankingCurrentAccountsServiceApplication.class, args);
	}

}
