package com.intecbrussel.bankingscheduler;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingSchedulerApplicationTests {

	@Test
	void contextLoads() {
	}

}
