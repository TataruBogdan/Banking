package com.intecbrussel.bankingscheduler;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankingSchedulerApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankingSchedulerApplication.class, args);
	}

}
