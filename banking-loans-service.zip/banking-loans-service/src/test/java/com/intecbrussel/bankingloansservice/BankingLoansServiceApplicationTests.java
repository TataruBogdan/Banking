package com.intecbrussel.bankingloansservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingLoansServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
