package com.intecbrussel.commonsservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommonsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
