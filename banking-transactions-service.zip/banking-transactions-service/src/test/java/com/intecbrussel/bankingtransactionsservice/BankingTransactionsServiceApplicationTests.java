package com.intecbrussel.bankingtransactionsservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingTransactionsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
