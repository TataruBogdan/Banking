package com.intecbrussel.bankingclientsservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingClientsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
