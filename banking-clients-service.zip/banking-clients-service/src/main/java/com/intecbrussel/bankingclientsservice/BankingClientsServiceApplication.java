package com.intecbrussel.bankingclientsservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankingClientsServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankingClientsServiceApplication.class, args);
	}

}
