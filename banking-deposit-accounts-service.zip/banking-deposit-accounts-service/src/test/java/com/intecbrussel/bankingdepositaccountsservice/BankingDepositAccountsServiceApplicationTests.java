package com.intecbrussel.bankingdepositaccountsservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingDepositAccountsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
